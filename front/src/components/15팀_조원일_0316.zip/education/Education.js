import React, { useState } from "react";

import EducationCard from "./EducationCard";
import EducationEditForm from "./EducationEditForm";

const Education = ({ education, setEducationLists, isEditable }) => {
  const [isEditing, setIsEditing] = useState(false);

  return (
    <>
      {isEditing ? (
        <EducationEditForm
          currentEducation={education}
          setIsEditing={setIsEditing}
          setEducationLists={setEducationLists}
        />
      ) : (
        <EducationCard
          education={education}
          setIsEditing={setIsEditing}
          setEducationLists={setEducationLists}
        />
      )}
    </>
  );
};

export default Education;
